/** Automatically generated file. DO NOT MODIFY */
package cn.sharesdk.ane;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}